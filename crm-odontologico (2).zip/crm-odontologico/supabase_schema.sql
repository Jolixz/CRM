-- CRM Odontológico · Esquema multi-centro para Supabase
-- Pégalo en: Supabase > SQL Editor > New query > Run
-- Si ya ejecutaste la versión anterior (de un solo centro), este script la reemplaza:
-- borra esas tablas, así que úsalo solo mientras no tengas datos reales.

drop table if exists public.payments, public.odontograms, public.treatments,
  public.consultations, public.appointments, public.patients,
  public.clinic_invites, public.profiles, public.clinics cascade;
drop function if exists public.app_role(), public.my_clinic(),
  public.create_clinic(text), public.join_clinic(text), public.handle_new_user() cascade;

-- 1) Centros odontológicos (cada uno es un "inquilino" con sus propios datos)
create table public.clinics (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text, email text, address text,
  created_at timestamptz default now()
);

-- Perfil de cada usuario: a qué centro pertenece y con qué rol
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  clinic_id uuid references public.clinics(id) on delete set null,
  full_name text,
  role text not null default 'reception' check (role in ('admin','dentist','reception'))
);

-- Código para invitar personal al centro (solo lo ve el administrador)
create table public.clinic_invites (
  clinic_id uuid primary key references public.clinics(id) on delete cascade,
  code text not null unique default substr(md5(random()::text || clock_timestamp()::text), 1, 8)
);

create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.email));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

create function public.my_clinic() returns uuid
language sql stable security definer set search_path = public as
$$ select clinic_id from public.profiles where id = auth.uid() $$;

create function public.app_role() returns text
language sql stable security definer set search_path = public as
$$ select role from public.profiles where id = auth.uid() $$;

-- Crear un centro nuevo: quien lo crea queda como administrador
create function public.create_clinic(clinic_name text) returns uuid
language plpgsql security definer set search_path = public as $$
declare cid uuid;
begin
  if auth.uid() is null then raise exception 'No autenticado'; end if;
  if public.my_clinic() is not null then raise exception 'Ya perteneces a un centro'; end if;
  insert into public.clinics (name) values (clinic_name) returning id into cid;
  insert into public.clinic_invites (clinic_id) values (cid);
  update public.profiles set clinic_id = cid, role = 'admin' where id = auth.uid();
  return cid;
end $$;

-- Unirse a un centro existente con su código de invitación (entra como recepción)
create function public.join_clinic(invite text) returns uuid
language plpgsql security definer set search_path = public as $$
declare cid uuid;
begin
  if auth.uid() is null then raise exception 'No autenticado'; end if;
  if public.my_clinic() is not null then raise exception 'Ya perteneces a un centro'; end if;
  select clinic_id into cid from public.clinic_invites where code = lower(trim(invite));
  if cid is null then raise exception 'Código inválido'; end if;
  update public.profiles set clinic_id = cid, role = 'reception' where id = auth.uid();
  return cid;
end $$;

revoke all on function public.create_clinic(text), public.join_clinic(text) from public, anon;
grant execute on function public.create_clinic(text), public.join_clinic(text) to authenticated;

-- 2) Tablas de datos: todas llevan clinic_id y se llenan solas con el del usuario
create table public.patients (
  id bigint generated always as identity primary key,
  clinic_id uuid not null default public.my_clinic() references public.clinics(id) on delete cascade,
  code text, name text not null, document text, phone text, email text,
  birth date, last_visit text,
  status text not null default 'Activo' check (status in ('Activo','Archivado')),
  allergy text default 'Ninguna',
  created_at timestamptz default now()
);
create table public.appointments (
  id bigint generated always as identity primary key,
  clinic_id uuid not null default public.my_clinic() references public.clinics(id) on delete cascade,
  appointment_date date not null default current_date,
  time text not null, patient text not null, reason text, doctor text,
  status text not null default 'Programada'
    check (status in ('Confirmada','Programada','En espera','Completada')),
  duration text default '45 min'
);
create table public.consultations (
  id bigint generated always as identity primary key,
  clinic_id uuid not null default public.my_clinic() references public.clinics(id) on delete cascade,
  patient text not null, date text, doctor text, diagnosis text, procedure text,
  created_at timestamptz default now()
);
create table public.treatments (
  id bigint generated always as identity primary key,
  clinic_id uuid not null default public.my_clinic() references public.clinics(id) on delete cascade,
  patient text not null, procedure text not null, tooth text default '—',
  price numeric(10,2) not null default 0,
  status text not null default 'Pendiente' check (status in ('Pendiente','En curso','Completado'))
);
create table public.odontograms (
  clinic_id uuid not null default public.my_clinic() references public.clinics(id) on delete cascade,
  patient text not null, teeth jsonb not null default '{}',
  primary key (clinic_id, patient)
);
create table public.payments (
  id bigint generated always as identity primary key,
  clinic_id uuid not null default public.my_clinic() references public.clinics(id) on delete cascade,
  patient text not null, concept text,
  amount numeric(10,2) not null, paid_at date not null default current_date
);

-- 3) Seguridad: cada centro solo ve lo suyo, y dentro del centro cada rol lo que le toca
alter table public.clinics        enable row level security;
alter table public.profiles       enable row level security;
alter table public.clinic_invites enable row level security;
alter table public.patients       enable row level security;
alter table public.appointments   enable row level security;
alter table public.consultations  enable row level security;
alter table public.treatments     enable row level security;
alter table public.odontograms    enable row level security;
alter table public.payments       enable row level security;

create policy "ver mi centro" on public.clinics for select using (id = public.my_clinic());
create policy "admin edita centro" on public.clinics for update
  using (id = public.my_clinic() and public.app_role() = 'admin')
  with check (id = public.my_clinic());

create policy "ver perfiles" on public.profiles for select
  using (id = auth.uid() or (clinic_id = public.my_clinic() and public.app_role() = 'admin'));
create policy "admin edita perfiles" on public.profiles for update
  using (clinic_id = public.my_clinic() and public.app_role() = 'admin')
  with check (clinic_id = public.my_clinic());

create policy "admin ve invitación" on public.clinic_invites for select
  using (clinic_id = public.my_clinic() and public.app_role() = 'admin');

-- Pacientes y agenda: todo el personal del centro
create policy "pacientes del centro" on public.patients for all
  using (clinic_id = public.my_clinic() and public.app_role() is not null)
  with check (clinic_id = public.my_clinic());
create policy "agenda del centro" on public.appointments for all
  using (clinic_id = public.my_clinic() and public.app_role() is not null)
  with check (clinic_id = public.my_clinic());

-- Datos clínicos: odontólogos y administrador
create policy "consultas clinicas" on public.consultations for all
  using (clinic_id = public.my_clinic() and public.app_role() in ('admin','dentist'))
  with check (clinic_id = public.my_clinic());
create policy "tratamientos clinicos" on public.treatments for all
  using (clinic_id = public.my_clinic() and public.app_role() in ('admin','dentist'))
  with check (clinic_id = public.my_clinic());
create policy "odontogramas clinicos" on public.odontograms for all
  using (clinic_id = public.my_clinic() and public.app_role() in ('admin','dentist'))
  with check (clinic_id = public.my_clinic());

-- Pagos: administrador y recepción
create policy "caja del centro" on public.payments for all
  using (clinic_id = public.my_clinic() and public.app_role() in ('admin','reception'))
  with check (clinic_id = public.my_clinic());
