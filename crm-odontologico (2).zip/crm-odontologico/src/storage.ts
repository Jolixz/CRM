// Almacenamiento por centro: cada centro odontológico guarda sus datos con su propio prefijo.
// Cuando conectes Supabase, esta capa se reemplaza por llamadas a la base de datos.
let tenant = ''
try {
  const v = JSON.parse(window.localStorage.getItem('smileup-session') || 'null')
  if (v && v.slug) tenant = v.slug
} catch (e) {}

const key = (k: string) =>
  k !== 'smileup-session' && k.indexOf('smileup-') === 0 ? 'crm:' + tenant + ':' + k.slice(8) : k

export const safeStorage = {
  setTenant(t: string) {
    tenant = t
  },
  getItem(k: string): string | null {
    try { return window.localStorage.getItem(key(k)) } catch (e) { return null }
  },
  setItem(k: string, v: string) {
    try { window.localStorage.setItem(key(k), v) } catch (e) {}
  },
  removeItem(k: string) {
    try { window.localStorage.removeItem(key(k)) } catch (e) {}
  },
}
