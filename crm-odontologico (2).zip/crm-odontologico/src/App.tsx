import { FormEvent, ReactNode, useEffect, useMemo, useState } from "react"
import { safeStorage } from "./storage"

type Section = "Inicio" | "Pacientes" | "Agenda" | "Consultas" | "Historias clínicas" | "Odontograma" | "Tratamientos" | "Reporte de ingresos" | "Configuración"

type Patient = {
  id: number
  code: string
  name: string
  document: string
  phone: string
  email: string
  birth: string
  lastVisit: string
  status: "Activo" | "Archivado"
  allergy: string
}

type Appointment = {
  id: number
  time: string
  patient: string
  reason: string
  doctor: string
  status: "Confirmada" | "Programada" | "En espera" | "Completada"
  duration: string
}

type Consultation = {
  id: number
  patient: string
  date: string
  doctor: string
  diagnosis: string
  procedure: string
}

type Income = {
  id: string
  date: string
  patient: string
  concept: string
  doctor: string
  method: "Tarjeta" | "Transferencia" | "Efectivo"
  amount: number
}

const initialPatients: Patient[] = [
  {
    id: 1,
    code: "SU-0248",
    name: "María Fernanda López",
    document: "76451289",
    phone: "987 245 130",
    email: "maria.lopez@email.com",
    birth: "1993-05-16",
    lastVisit: "Hoy, 09:30",
    status: "Activo",
    allergy: "Penicilina",
  },
  {
    id: 2,
    code: "SU-0247",
    name: "Carlos Mendoza Ruiz",
    document: "45890217",
    phone: "956 110 842",
    email: "carlos.mendoza@email.com",
    birth: "1986-11-02",
    lastVisit: "Ayer, 16:00",
    status: "Activo",
    allergy: "Sin alergias",
  },
  {
    id: 3,
    code: "SU-0246",
    name: "Valentina Pérez Soto",
    document: "73156420",
    phone: "990 361 524",
    email: "valentina.p@email.com",
    birth: "2001-08-27",
    lastVisit: "12 Jun, 11:15",
    status: "Activo",
    allergy: "Ibuprofeno",
  },
  {
    id: 4,
    code: "SU-0245",
    name: "José Antonio Salazar",
    document: "41256783",
    phone: "944 813 002",
    email: "jose.salazar@email.com",
    birth: "1978-03-09",
    lastVisit: "10 Jun, 15:30",
    status: "Activo",
    allergy: "Sin alergias",
  },
  {
    id: 5,
    code: "SU-0244",
    name: "Ana Lucía Torres",
    document: "70819462",
    phone: "921 745 300",
    email: "ana.torres@email.com",
    birth: "1998-12-14",
    lastVisit: "08 Jun, 10:00",
    status: "Activo",
    allergy: "Látex",
  },
]

const initialAppointments: Appointment[] = [
  {
    id: 1,
    time: "09:00",
    patient: "María Fernanda López",
    reason: "Control de ortodoncia",
    doctor: "Dra. Andrea Ramos",
    status: "Confirmada",
    duration: "45 min",
  },
  {
    id: 2,
    time: "10:00",
    patient: "Diego Castro Vega",
    reason: "Profilaxis dental",
    doctor: "Dr. Luis Cárdenas",
    status: "En espera",
    duration: "30 min",
  },
  {
    id: 3,
    time: "11:30",
    patient: "Valentina Pérez Soto",
    reason: "Restauración pieza 26",
    doctor: "Dra. Andrea Ramos",
    status: "Programada",
    duration: "60 min",
  },
  {
    id: 4,
    time: "14:30",
    patient: "Carlos Mendoza Ruiz",
    reason: "Evaluación integral",
    doctor: "Dr. Luis Cárdenas",
    status: "Confirmada",
    duration: "45 min",
  },
  {
    id: 5,
    time: "16:00",
    patient: "Ana Lucía Torres",
    reason: "Blanqueamiento",
    doctor: "Dra. Andrea Ramos",
    status: "Programada",
    duration: "60 min",
  },
]

const initialConsultations: Consultation[] = [
  {
    id: 1,
    patient: "María Fernanda López",
    date: "18 Jun 2025 · 09:45",
    doctor: "Dra. Andrea Ramos",
    diagnosis: "Maloclusión clase II",
    procedure: "Ajuste de arco superior",
  },
  {
    id: 2,
    patient: "Carlos Mendoza Ruiz",
    date: "17 Jun 2025 · 16:30",
    doctor: "Dr. Luis Cárdenas",
    diagnosis: "Gingivitis localizada",
    procedure: "Profilaxis y destartraje",
  },
  {
    id: 3,
    patient: "Valentina Pérez Soto",
    date: "12 Jun 2025 · 12:10",
    doctor: "Dra. Andrea Ramos",
    diagnosis: "Caries oclusal pieza 26",
    procedure: "Restauración con resina",
  },
]

const incomeRecords: Income[] = [
  {
    id: "ING-1048",
    date: "2025-06-18",
    patient: "María Fernanda López",
    concept: "Control de ortodoncia",
    doctor: "Dra. Andrea Ramos",
    method: "Tarjeta",
    amount: 280,
  },
  {
    id: "ING-1047",
    date: "2025-06-18",
    patient: "Diego Castro Vega",
    concept: "Profilaxis dental",
    doctor: "Dr. Luis Cárdenas",
    method: "Transferencia",
    amount: 160,
  },
  {
    id: "ING-1046",
    date: "2025-06-17",
    patient: "Carlos Mendoza Ruiz",
    concept: "Evaluación integral",
    doctor: "Dr. Luis Cárdenas",
    method: "Efectivo",
    amount: 120,
  },
  {
    id: "ING-1045",
    date: "2025-06-16",
    patient: "Valentina Pérez Soto",
    concept: "Restauración pieza 26",
    doctor: "Dra. Andrea Ramos",
    method: "Tarjeta",
    amount: 350,
  },
  {
    id: "ING-1044",
    date: "2025-06-14",
    patient: "Ana Lucía Torres",
    concept: "Blanqueamiento dental",
    doctor: "Dra. Andrea Ramos",
    method: "Transferencia",
    amount: 680,
  },
  {
    id: "ING-1043",
    date: "2025-06-12",
    patient: "José Antonio Salazar",
    concept: "Tratamiento periodontal",
    doctor: "Dr. Luis Cárdenas",
    method: "Efectivo",
    amount: 420,
  },
  {
    id: "ING-1042",
    date: "2025-05-29",
    patient: "Lucía Romero Díaz",
    concept: "Extracción simple",
    doctor: "Dra. Andrea Ramos",
    method: "Tarjeta",
    amount: 300,
  },
]

const navItems: { label: Section; icon: string }[] = [
  { label: "Inicio", icon: "home" },
  { label: "Pacientes", icon: "users" },
  { label: "Agenda", icon: "calendar" },
  { label: "Consultas", icon: "clipboard" },
  { label: "Historias clínicas", icon: "file" },
  { label: "Odontograma", icon: "tooth" },
  { label: "Tratamientos", icon: "sparkles" },
  { label: "Reporte de ingresos", icon: "chart" },
  { label: "Configuración", icon: "settings" },
]

const iconPaths: Record<string, ReactNode> = {
  home: (
    <>
      <path d="m3 11 9-8 9 8" />
      <path d="M5 10v10h14V10M9 20v-6h6v6" />
    </>
  ),
  users: (
    <>
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
    </>
  ),
  calendar: (
    <>
      <rect x="3" y="5" width="18" height="16" rx="2" />
      <path d="M16 3v4M8 3v4M3 10h18" />
      <path d="M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01" />
    </>
  ),
  clipboard: (
    <>
      <rect x="5" y="4" width="14" height="17" rx="2" />
      <path d="M9 4V2h6v2M9 10h6M9 14h6M9 18h3" />
    </>
  ),
  file: (
    <>
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z" />
      <path d="M14 2v6h6M8 13h8M8 17h6" />
    </>
  ),
  tooth: (
    <path d="M12 3c-2.8-2.1-7-1-8 2.5-1 3.4 1.2 5.2 1.8 8.8.5 3.1 1.1 6.7 3 6.7 1.6 0 1.5-5.7 3.2-5.7s1.6 5.7 3.2 5.7c1.9 0 2.5-3.6 3-6.7.6-3.6 2.8-5.4 1.8-8.8C19 2 14.8.9 12 3Z" />
  ),
  sparkles: (
    <>
      <path d="m12 3-1.2 3.2L8 7.5l2.8 1.3L12 12l1.2-3.2L16 7.5l-2.8-1.3Z" />
      <path d="m5 13-.8 2.2L2 16l2.2.8L5 19l.8-2.2L8 16l-2.2-.8ZM19 13l-.6 1.4L17 15l1.4.6L19 17l.6-1.4L21 15l-1.4-.6Z" />
    </>
  ),
  wallet: (
    <>
      <path d="M3 6h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h13" />
      <path d="M16 12h5M16 12v4h5" />
    </>
  ),
  box: (
    <>
      <path d="m21 8-9 5-9-5 9-5 9 5Z" />
      <path d="m3 8 9 5 9-5v9l-9 5-9-5Z M12 13v9" />
    </>
  ),
  chart: (
    <>
      <path d="M4 20V10M10 20V4M16 20v-7M22 20H2" />
    </>
  ),
  settings: (
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3 1.7 1.7 0 0 0 1-1.6v-.2h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" />
    </>
  ),
  search: (
    <>
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-4-4" />
    </>
  ),
  bell: (
    <>
      <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" />
    </>
  ),
  plus: <path d="M12 5v14M5 12h14" />,
  arrow: <path d="m9 18 6-6-6-6" />,
  trend: (
    <>
      <path d="m3 17 6-6 4 4 8-9" />
      <path d="M15 6h6v6" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </>
  ),
  chevron: <path d="m6 9 6 6 6-6" />,
  menu: <path d="M4 6h16M4 12h16M4 18h16" />,
  close: <path d="m6 6 12 12M18 6 6 18" />,
  eye: (
    <>
      <path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z" />
      <circle cx="12" cy="12" r="2.5" />
    </>
  ),
  logout: (
    <>
      <path d="M10 17l5-5-5-5M15 12H3M15 4h4a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-4" />
    </>
  ),
  check: <path d="m5 12 4 4L19 6" />,
}

function Icon({ name, size = 20 }: { name: string; size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {iconPaths[name]}
    </svg>
  )
}

let CURRENT_CLINIC = ""

function Brand({ dark = false, product = false }: { dark?: boolean; product?: boolean }) {
  return (
    <div
      className={`brand ${dark ? "brand-dark" : ""}`}
      aria-label={product ? "CRM Odontológico" : CURRENT_CLINIC}
    >
      {product ? (
        <>
          <div className="brand-name brand-crm">
            CRM <span>ODONTOLÓGICO</span>
          </div>
          <div className="brand-tagline">PLATAFORMA PARA CENTROS DENTALES</div>
        </>
      ) : (
        <>
          <div className="brand-name brand-clinic">{CURRENT_CLINIC.toUpperCase()}</div>
          <div className="brand-tagline">CRM ODONTOLÓGICO</div>
        </>
      )}
    </div>
  )
}

function Button({
  children,
  variant = "primary",
  className = "",
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost"
}) {
  return (
    <button className={`btn btn-${variant} ${className}`} {...props}>
      {children}
    </button>
  )
}

function Status({ children }: { children: string }) {
  return (
    <span
      className={`status status-${children.toLowerCase().replace(" ", "-")}`}
    >
      <i />
      {children}
    </span>
  )
}

function Login({ onLogin }: { onLogin: (c: any) => void }) {
  const [mode, setMode] = useState<"login" | "register">("login")
  const [centerName, setCenterName] = useState("")
  const [email, setEmail] = useState("")
  const [forgotSent, setForgotSent] = useState(false)
  const [password, setPassword] = useState("")
  const [show, setShow] = useState(false)
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  const switchMode = (m: "login" | "register") => {
    setMode(m)
    setError("")
    setEmail("")
    setPassword("")
  }

  const submit = (event: FormEvent) => {
    event.preventDefault()
    const mail = email.trim().toLowerCase()
    if (!mail.includes("@") || password.length < 6) {
      setError("Ingresa un correo válido y una contraseña de al menos 6 caracteres.")
      return
    }
    let accounts: Record<string, any> = {}
    try {
      accounts = JSON.parse(safeStorage.getItem("crm-accounts") || "{}")
    } catch (e) {}
    accounts["admin@smileup.pe"] = { slug: "smile-up-demo", name: "Smile Up Centro Odontológico" }
    let clinic = accounts[mail]
    if (mode === "register") {
      if (centerName.trim().length < 3) {
        setError("Escribe el nombre de tu centro odontológico.")
        return
      }
      if (clinic) {
        setError("Ese correo ya tiene un centro. Inicia sesión.")
        return
      }
      const slug =
        centerName.toLowerCase().normalize("NFD").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") +
        "-" + Math.random().toString(36).slice(2, 6)
      clinic = { slug, name: centerName.trim() }
      accounts[mail] = clinic
      safeStorage.setItem("crm-accounts", JSON.stringify(accounts))
    } else if (!clinic) {
      setError("No encontramos ese correo. Crea tu centro para empezar.")
      return
    }
    setLoading(true)
    window.setTimeout(() => {
      const session = { slug: clinic.slug, name: clinic.name, email: mail }
      safeStorage.setTenant(session.slug)
      safeStorage.setItem("smileup-session", JSON.stringify(session))
      setLoading(false)
      onLogin(session)
    }, 600)
  }

  return (
    <main className="login-page">
      <div className="login-brand">
        <Brand dark product />
        <p>Una sola plataforma para todos los centros odontológicos: cada uno con sus pacientes, agenda y configuración.</p>
        <div className="login-art" aria-hidden="true">
          <span className="orbit orbit-one" />
          <span className="orbit orbit-two" />
          <div className="tooth-art">
            <Icon name="tooth" size={72} />
          </div>
        </div>
      </div>
      <section className="login-panel">
        <div className="login-card">
          <div className="mobile-brand">
            <Brand product />
          </div>
          <div className="x-tabs">
            <button className={mode === "login" ? "x-active" : ""} onClick={() => switchMode("login")}>Iniciar sesión</button>
            <button className={mode === "register" ? "x-active" : ""} onClick={() => switchMode("register")}>Crear mi centro</button>
          </div>
          <span className="eyebrow">{mode === "login" ? "ACCESO SEGURO" : "NUEVO CENTRO"}</span>
          <h1>{mode === "login" ? "Bienvenido de nuevo" : "Registra tu centro"}</h1>
          <p className="muted">
            {mode === "login"
              ? "Ingresa con tu cuenta para abrir el espacio de tu centro."
              : "Crea el espacio de tu centro odontológico. Empieza con datos vacíos."}
          </p>
          <form onSubmit={submit}>
            {mode === "register" && (
              <>
                <label htmlFor="center">Nombre del centro odontológico</label>
                <div className="input-wrap">
                  <Icon name="tooth" size={18} />
                  <input id="center" value={centerName} onChange={(e) => { setCenterName(e.target.value); setError("") }} placeholder="Ej. Clínica Sonrisa" />
                </div>
              </>
            )}
            <label htmlFor="email">Usuario o correo electrónico</label>
            <div className="input-wrap">
              <Icon name="users" size={18} />
              <input
                id="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value)
                  setError("")
                }}
                placeholder="correo@micentro.com"
              />
            </div>
            <div className="password-row">
              <label htmlFor="password">Contraseña</label>
              <button type="button" className="link-button" onClick={() => setForgotSent(true)}>
                {forgotSent ? "✓ Enviamos un enlace a tu correo (demo)" : "¿Olvidaste tu contraseña?"}
              </button>
            </div>
            <div className="input-wrap">
              <Icon name="file" size={18} />
              <input
                id="password"
                type={show ? "text" : "password"}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value)
                  setError("")
                }}
              />
              <button
                type="button"
                onClick={() => setShow(!show)}
                className="icon-button"
                aria-label="Mostrar u ocultar contraseña"
              >
                <Icon name="eye" size={18} />
              </button>
            </div>
            {error && <div className="form-error">{error}</div>}
            <Button type="submit" className="login-button" disabled={loading}>
              {loading ? "Verificando…" : mode === "login" ? "Iniciar sesión" : "Crear centro y entrar"}{" "}
              {!loading && <Icon name="arrow" size={18} />}
            </Button>
          </form>
          <small>© 2026 CRM Odontológico</small>
        </div>
      </section>
    </main>
  )
}

function Header({
  section,
  search,
  setSearch,
  toggleMenu,
  goTo,
  logout,
}: {
  section: Section
  search: string
  setSearch: (value: string) => void
  toggleMenu: () => void
  goTo: (s: Section) => void
  logout: () => void
}) {
  const [panel, setPanel] = useState("")
  const [notes, setNotes] = useState([
    { id: 1, text: "Cita confirmada: paciente de las 09:30", read: false },
    { id: 2, text: "Recordatorio: control de ortodoncia a las 11:00", read: false },
    { id: 3, text: "Pago pendiente de S/ 150.00 por cobrar", read: false },
  ])
  const unread = notes.filter((n) => !n.read).length
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault()
        const el = document.querySelector(".global-search input") as HTMLInputElement | null
        el?.focus()
      }
    }
    window.addEventListener("keydown", h)
    return () => window.removeEventListener("keydown", h)
  }, [])
  return (
    <header className="topbar">
      {panel && <div className="popover-backdrop" onClick={() => setPanel("")} />}
      <div className="topbar-title">
        <button
          className="mobile-menu"
          onClick={toggleMenu}
          aria-label="Abrir menú"
        >
          <Icon name="menu" />
        </button>
        <div>
          <span className="page-kicker">{CURRENT_CLINIC.toUpperCase()}</span>
          <h1>{section}</h1>
        </div>
      </div>
      <div className="topbar-actions">
        <div className="global-search">
          <Icon name="search" size={19} />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar paciente, cita…"
          />
          <kbd>⌘ K</kbd>
        </div>
        <div className="pop-wrap">
          <button
            className="notification"
            aria-label="Notificaciones"
            onClick={() => setPanel(panel === "bell" ? "" : "bell")}
          >
            <Icon name="bell" />
            {unread > 0 && <span>{unread}</span>}
          </button>
          {panel === "bell" && (
            <div className="popover">
              <div className="popover-head">
                <b>Notificaciones</b>
                <button onClick={() => setNotes(notes.map((n) => ({ ...n, read: true })))}>
                  Marcar todas como leídas
                </button>
              </div>
              {notes.map((n) => (
                <button
                  key={n.id}
                  className={`popover-item ${n.read ? "" : "unread"}`}
                  onClick={() => setNotes(notes.map((x) => (x.id === n.id ? { ...x, read: true } : x)))}
                >
                  {n.text}
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="profile" role="button" tabIndex={0} onClick={() => setPanel(panel === "user" ? "" : "user")}>
          <div className="avatar">AR</div>
          <div>
            <b>Dra. Andrea Ramos</b>
            <small>Odontóloga general</small>
          </div>
          <Icon name="chevron" size={16} />
          {panel === "user" && (
            <div className="popover popover-user" onClick={(e) => e.stopPropagation()}>
              <button className="popover-item" onClick={() => { goTo("Configuración"); setPanel("") }}>Configuración</button>
              <button className="popover-item" onClick={logout}>Cerrar sesión</button>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}

function Sidebar({
  section,
  setSection,
  open,
  close,
  logout,
}: {
  section: Section
  setSection: (value: Section) => void
  open: boolean
  close: () => void
  logout: () => void
}) {
  return (
    <>
      {open && <div className="sidebar-overlay" onClick={close} />}
      <aside className={`sidebar ${open ? "sidebar-open" : ""}`}>
        <div className="sidebar-head">
          <Brand dark />
          <button className="sidebar-close" onClick={close}>
            <Icon name="close" />
          </button>
        </div>
        <nav>
          <span className="nav-label">MENÚ PRINCIPAL</span>
          {navItems.slice(0, -1).map((item) => (
            <button
              key={item.label}
              onClick={() => {
                setSection(item.label)
                close()
              }}
              className={section === item.label ? "active" : ""}
            >
              <Icon name={item.icon} />
              <span>{item.label}</span>
              {item.label === "Agenda" && <em>8</em>}
            </button>
          ))}
          <span className="nav-label nav-secondary">SISTEMA</span>
          {navItems.slice(-1).map((item) => (
            <button
              key={item.label}
              onClick={() => {
                setSection(item.label)
                close()
              }}
              className={section === item.label ? "active" : ""}
            >
              <Icon name={item.icon} />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>
        <div className="sidebar-user">
          <div className="avatar">AR</div>
          <div>
            <b>Andrea Ramos</b>
            <small>Administradora</small>
          </div>
          <button onClick={logout} aria-label="Cerrar sesión">
            <Icon name="logout" size={18} />
          </button>
        </div>
      </aside>
    </>
  )
}

function MetricCard({
  label,
  value,
  note,
  icon,
  accent,
}: {
  label: string
  value: string
  note: string
  icon: string
  accent?: boolean
}) {
  return (
    <article className={`metric-card ${accent ? "metric-accent" : ""}`}>
      <div className="metric-top">
        <span className="metric-icon">
          <Icon name={icon} />
        </span>
        <span className="trend">
          <Icon name="trend" size={14} /> {note}
        </span>
      </div>
      <strong>{value}</strong>
      <p>{label}</p>
    </article>
  )
}

function Dashboard({
  appointments,
  goTo,
}: {
  appointments: Appointment[]
  goTo: (section: Section) => void
}) {
  const bars = [42, 55, 46, 72, 65, 82, 70, 88, 62, 77, 94, 84]
  return (
    <div className="page dashboard">
      <section className="welcome">
        <div>
          <span className="eyebrow">MIÉRCOLES, 18 DE JUNIO</span>
          <h2>Buenos días, Andrea</h2>
          <p>
            Tu clínica tiene <b>8 citas</b> programadas para hoy.
          </p>
        </div>
        <Button onClick={() => goTo("Agenda")}>
          <Icon name="plus" size={18} /> Nueva cita
        </Button>
      </section>
      <section className="metrics-grid">
        <MetricCard
          label="Pacientes registrados"
          value="248"
          note="+12 este mes"
          icon="users"
        />
        <MetricCard
          label="Citas para hoy"
          value="8"
          note="6 confirmadas"
          icon="calendar"
          accent
        />
        <MetricCard
          label="Consultas atendidas"
          value="1,284"
          note="+8.4%"
          icon="clipboard"
        />
        <MetricCard
          label="Tratamientos activos"
          value="36"
          note="5 por finalizar"
          icon="sparkles"
        />
        <MetricCard
          label="Ingresos del mes"
          value="S/ 34,820"
          note="+12.5%"
          icon="chart"
        />
      </section>
      <section className="dashboard-grid">
        <article className="card schedule-card">
          <div className="card-head">
            <div>
              <h3>Agenda de hoy</h3>
              <p>8 citas · Miércoles 18</p>
            </div>
            <Button variant="ghost" onClick={() => goTo("Agenda")}>
              Ver agenda <Icon name="arrow" size={15} />
            </Button>
          </div>
          <div className="appointment-list">
            {appointments.slice(0, 4).map((appointment) => (
              <div className="appointment" key={appointment.id}>
                <div className="time">
                  {appointment.time}
                  <small>{appointment.duration}</small>
                </div>
                <div className="timeline">
                  <i />
                </div>
                <div className="appointment-info">
                  <b>{appointment.patient}</b>
                  <span>{appointment.reason}</span>
                  <small>{appointment.doctor}</small>
                </div>
                <Status>{appointment.status}</Status>
              </div>
            ))}
          </div>
        </article>
        <article className="card activity-card">
          <div className="card-head">
            <div>
              <h3>Actividad de la clínica</h3>
              <p>Consultas de los últimos 12 meses</p>
            </div>
            <select aria-label="Periodo">
              <option>Este año</option>
              <option>Año anterior</option>
            </select>
          </div>
          <div className="chart-wrap">
            <div className="y-labels">
              <span>120</span>
              <span>80</span>
              <span>40</span>
              <span>0</span>
            </div>
            <div className="bars">
              {bars.map((height, index) => (
                <div className="bar-col" key={index}>
                  <div className="bar" style={{ height: `${height}%` }}>
                    <span>{Math.round(height * 1.2)}</span>
                  </div>
                  <small>
                    {
                      [
                        "Jul",
                        "Ago",
                        "Sep",
                        "Oct",
                        "Nov",
                        "Dic",
                        "Ene",
                        "Feb",
                        "Mar",
                        "Abr",
                        "May",
                        "Jun",
                      ][index]
                    }
                  </small>
                </div>
              ))}
            </div>
          </div>
          <div className="chart-summary">
            <span>
              <i className="dot-green" /> Consultas <b>1,284</b>
            </span>
            <span>
              <i className="dot-mint" /> Nuevos pacientes <b>142</b>
            </span>
          </div>
        </article>
      </section>
      <section className="bottom-grid">
        <article className="card quick-card">
          <div className="card-head">
            <div>
              <h3>Acciones rápidas</h3>
              <p>Accesos frecuentes</p>
            </div>
          </div>
          <div className="quick-actions">
            <button onClick={() => goTo("Pacientes")}>
              <span>
                <Icon name="users" />
              </span>
              <b>Nuevo paciente</b>
              <small>Registrar ficha clínica</small>
            </button>
            <button onClick={() => goTo("Consultas")}>
              <span>
                <Icon name="clipboard" />
              </span>
              <b>Nueva consulta</b>
              <small>Iniciar atención</small>
            </button>
            <button onClick={() => goTo("Reporte de ingresos")}>
              <span>
                <Icon name="chart" />
              </span>
              <b>Ver ingresos</b>
              <small>Consultar reporte</small>
            </button>
          </div>
        </article>
        <article className="card pending-card">
          <div className="card-head">
            <div>
              <h3>Resumen financiero</h3>
              <p>Ingresos del mes</p>
            </div>
            <button className="more" aria-label="Ver reporte de ingresos" onClick={() => goTo("Reporte de ingresos")}>•••</button>
          </div>
          <strong>S/ 34,820.00</strong>
          <span className="positive">
            <Icon name="trend" size={15} /> 12.5% vs. mes anterior
          </span>
          <div className="progress">
            <i />
          </div>
          <small>Meta mensual: S/ 45,000</small>
        </article>
      </section>
    </div>
  )
}

function PatientModal({
  onClose,
  onSave,
}: {
  onClose: () => void
  onSave: (patient: Patient) => void
}) {
  const [form, setForm] = useState({
    name: "",
    document: "",
    phone: "",
    email: "",
    birth: "",
    allergy: "",
  })
  const update = (field: keyof typeof form, value: string) =>
    setForm({ ...form, [field]: value })
  const submit = (e: FormEvent) => {
    e.preventDefault()
    if (!form.name || !form.document || !form.phone) return
    onSave({
      ...form,
      id: Date.now(),
      code: `SU-${String(Date.now()).slice(-4)}`,
      lastVisit: "Sin consultas",
      status: "Activo",
    })
  }
  return (
    <div className="modal-backdrop">
      <section className="modal">
        <div className="modal-head">
          <div>
            <span className="eyebrow">NUEVA FICHA</span>
            <h2>Registrar paciente</h2>
          </div>
          <button onClick={onClose} className="modal-close">
            <Icon name="close" />
          </button>
        </div>
        <form onSubmit={submit} className="patient-form">
          <label className="full">
            Nombres y apellidos
            <input
              required
              value={form.name}
              onChange={(e) => update("name", e.target.value)}
              placeholder="Nombre completo"
            />
          </label>
          <label>
            Documento de identidad
            <input
              required
              value={form.document}
              onChange={(e) => update("document", e.target.value)}
              placeholder="DNI / CE"
            />
          </label>
          <label>
            Fecha de nacimiento
            <input
              type="date"
              value={form.birth}
              onChange={(e) => update("birth", e.target.value)}
            />
          </label>
          <label>
            Teléfono
            <input
              required
              value={form.phone}
              onChange={(e) => update("phone", e.target.value)}
              placeholder="999 999 999"
            />
          </label>
          <label>
            Correo electrónico
            <input
              type="email"
              value={form.email}
              onChange={(e) => update("email", e.target.value)}
              placeholder="correo@ejemplo.com"
            />
          </label>
          <label className="full">
            Alergias y antecedentes relevantes
            <textarea
              value={form.allergy}
              onChange={(e) => update("allergy", e.target.value)}
              placeholder="Registra alertas clínicas importantes"
            />
          </label>
          <div className="form-actions full">
            <Button type="button" variant="secondary" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit">Guardar paciente</Button>
          </div>
        </form>
      </section>
    </div>
  )
}

function Patients({
  patients,
  setPatients,
  search,
}: {
  patients: Patient[]
  setPatients: (patients: Patient[]) => void
  search: string
}) {
  const [localSearch, setLocalSearch] = useState("")
  const [modal, setModal] = useState(false)
  const [toast, setToast] = useState("")
  const [statusFilter, setStatusFilter] = useState("Todos")
  const [page, setPage] = useState(1)
  const [detail, setDetail] = useState<Patient | null>(null)
  const PAGE = 8
  const query = `${search} ${localSearch}`.trim().toLowerCase()
  const matched = patients.filter(
    (p) =>
      (!query ||
        `${p.name} ${p.document} ${p.code}`.toLowerCase().includes(query)) &&
      (statusFilter === "Todos" || p.status === statusFilter.replace(/s$/, "")),
  )
  const pages = Math.max(1, Math.ceil(matched.length / PAGE))
  const cur = Math.min(page, pages)
  const filtered = matched.slice((cur - 1) * PAGE, cur * PAGE)
  const toggleArchive = (p: Patient) => {
    const status = p.status === "Activo" ? "Archivado" : "Activo"
    setPatients(patients.map((x) => (x.id === p.id ? { ...x, status } : x)))
    setDetail(null)
    setToast(status === "Archivado" ? "Paciente archivado." : "Paciente reactivado.")
    window.setTimeout(() => setToast(""), 3000)
  }
  const save = (patient: Patient) => {
    setPatients([patient, ...patients])
    setModal(false)
    setToast("Paciente registrado correctamente.")
    window.setTimeout(() => setToast(""), 3000)
  }
  return (
    <div className="page">
      <section className="section-head">
        <div>
          <h2>Pacientes</h2>
          <p>Administra las fichas e información clínica de tus pacientes.</p>
        </div>
        <Button onClick={() => setModal(true)}>
          <Icon name="plus" size={18} /> Nuevo paciente
        </Button>
      </section>
      <section className="card table-card">
        <div className="table-tools">
          <div className="table-search">
            <Icon name="search" size={18} />
            <input
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              placeholder="Buscar por nombre, DNI o código"
            />
          </div>
          <div className="filter-pills">
            {["Todos", "Activos", "Archivados"].map((f) => (
              <button
                key={f}
                className={statusFilter === f ? "selected" : ""}
                onClick={() => { setStatusFilter(f); setPage(1) }}
              >
                {f}{" "}
                <b>
                  {f === "Todos"
                    ? patients.length
                    : patients.filter((p) => p.status === f.replace(/s$/, "")).length}
                </b>
              </button>
            ))}
          </div>
        </div>
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>Paciente</th>
                <th>Documento</th>
                <th>Contacto</th>
                <th>Última visita</th>
                <th>Estado</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((patient) => (
                <tr key={patient.id}>
                  <td>
                    <div className="patient-cell">
                      <div className="patient-avatar">
                        {patient.name
                          .split(" ")
                          .slice(0, 2)
                          .map((n) => n[0])
                          .join("")}
                      </div>
                      <div>
                        <b>{patient.name}</b>
                        <small>
                          {patient.code} · {patient.allergy}
                        </small>
                      </div>
                    </div>
                  </td>
                  <td>
                    <b>{patient.document}</b>
                    <small>DNI</small>
                  </td>
                  <td>
                    <b>{patient.phone}</b>
                    <small>{patient.email}</small>
                  </td>
                  <td>{patient.lastVisit}</td>
                  <td>
                    <Status>{patient.status}</Status>
                  </td>
                  <td>
                    <button
                      className="row-action"
                      aria-label={`Ver ${patient.name}`}
                      onClick={() => setDetail(patient)}
                    >
                      <Icon name="arrow" size={17} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="empty">
            <Icon name="search" size={28} />
            <h3>No encontramos pacientes</h3>
            <p>Prueba con otro nombre, documento o código.</p>
          </div>
        )}
        <div className="table-footer">
          <span>
            Mostrando {filtered.length} de {matched.length} pacientes
          </span>
          <div>
            <button disabled={cur <= 1} onClick={() => setPage(cur - 1)}>Anterior</button>
            <button className="page-active">{cur}</button>
            <button disabled={cur >= pages} onClick={() => setPage(cur + 1)}>Siguiente</button>
          </div>
        </div>
      </section>
      {modal && <PatientModal onClose={() => setModal(false)} onSave={save} />}
      {detail && (
        <div className="x-overlay" onClick={() => setDetail(null)}>
          <div className="card x-dialog" onClick={(e) => e.stopPropagation()}>
            <span className="eyebrow">{detail.code}</span>
            <h2 className="x-title">{detail.name}</h2>
            <div className="x-facts">
              <span><small>Documento</small><b>{detail.document}</b></span>
              <span><small>Teléfono</small><b>{detail.phone}</b></span>
              <span><small>Correo</small><b>{detail.email}</b></span>
              <span><small>Nacimiento</small><b>{detail.birth}</b></span>
              <span><small>Alergias</small><b className="x-warn">{detail.allergy}</b></span>
              <span><small>Estado</small><b>{detail.status}</b></span>
            </div>
            <div className="x-actions">
              <Button variant="secondary" onClick={() => setDetail(null)}>Cerrar</Button>
              <Button onClick={() => toggleArchive(detail)}>
                {detail.status === "Activo" ? "Archivar paciente" : "Reactivar paciente"}
              </Button>
            </div>
          </div>
        </div>
      )}
      {toast && (
        <div className="toast">
          <Icon name="check" size={18} />
          {toast}
        </div>
      )}
    </div>
  )
}

function Agenda({
  appointments,
  setAppointments,
  patients,
}: {
  appointments: Appointment[]
  setAppointments: (a: Appointment[]) => void
  patients: Patient[]
}) {
  const [view, setView] = useState("Semana")
  const [offset, setOffset] = useState(0)
  const [hidden, setHidden] = useState<string[]>([])
  const visible = offset === 0 ? appointments.filter((a) => !hidden.includes(a.doctor)) : []
  const order: Appointment["status"][] = ["Programada", "Confirmada", "En espera", "Completada"]
  const cycle = (a: Appointment) =>
    setAppointments(appointments.map((x) => x.id === a.id ? { ...x, status: order[(order.indexOf(a.status) + 1) % 4] } : x))
  const mon = new Date(); mon.setDate(mon.getDate() - ((mon.getDay() + 6) % 7) + offset * 7)
  const sat = new Date(mon); sat.setDate(mon.getDate() + 5)
  const fmt = (d: Date, y = false) => d.toLocaleDateString("es-PE", { day: "numeric", month: "long", ...(y ? { year: "numeric" } : {}) })
  const weekNo = Math.ceil(((mon.getTime() - new Date(mon.getFullYear(), 0, 1).getTime()) / 86400000 + 1) / 7)
  const [creating, setCreating] = useState(false)
  const [form, setForm] = useState({
    patient: patients[0]?.name || "",
    time: "09:00",
    reason: "",
    doctor: "Dra. Andrea Ramos",
  })
  const save = (e: FormEvent) => {
    e.preventDefault()
    if (!form.patient || !form.reason) return
    setAppointments([
      ...appointments,
      { id: Date.now(), ...form, status: "Programada", duration: "45 min" },
    ])
    setCreating(false)
    setForm({ ...form, reason: "" })
  }
  return (
    <div className="page">
      <section className="section-head">
        <div>
          <h2>Agenda odontológica</h2>
          <p>Organiza citas y disponibilidad del equipo clínico.</p>
        </div>
        <Button onClick={() => setCreating(!creating)}>
          <Icon name="plus" size={18} /> Nueva cita
        </Button>
      </section>
      {creating && (
        <section className="card inline-form">
          <form onSubmit={save}>
            <label>
              Paciente
              <select
                value={form.patient}
                onChange={(e) => setForm({ ...form, patient: e.target.value })}
              >
                {patients.map((p) => (
                  <option key={p.id}>{p.name}</option>
                ))}
              </select>
            </label>
            <label>
              Hora
              <input
                type="time"
                value={form.time}
                onChange={(e) => setForm({ ...form, time: e.target.value })}
              />
            </label>
            <label>
              Odontólogo
              <select
                value={form.doctor}
                onChange={(e) => setForm({ ...form, doctor: e.target.value })}
              >
                <option>Dra. Andrea Ramos</option>
                <option>Dr. Luis Cárdenas</option>
              </select>
            </label>
            <label className="wide">
              Motivo
              <input
                required
                value={form.reason}
                onChange={(e) => setForm({ ...form, reason: e.target.value })}
                placeholder="Motivo de la cita"
              />
            </label>
            <Button type="submit">Agendar cita</Button>
          </form>
        </section>
      )}
      <section className="card calendar-card">
        <div className="calendar-toolbar">
          <div className="date-nav">
            <button onClick={() => setOffset(offset - 1)} aria-label="Semana anterior">‹</button>
            <div>
              <b>{fmt(mon)} – {fmt(sat, true)}</b>
              <small>Semana {weekNo}</small>
            </div>
            <button onClick={() => setOffset(offset + 1)} aria-label="Semana siguiente">›</button>
            <Button variant="secondary" onClick={() => setOffset(0)}>Hoy</Button>
          </div>
          <div className="view-switch">
            {["Día", "Semana", "Mes"].map((item) => (
              <button
                className={view === item ? "selected" : ""}
                onClick={() => setView(item)}
                key={item}
              >
                {item}
              </button>
            ))}
          </div>
        </div>
        <div className="agenda-layout">
          <aside className="doctor-filter">
            <span className="nav-label">ODONTÓLOGOS</span>
            <label>
              <input type="checkbox" checked={!hidden.includes("Dra. Andrea Ramos")} onChange={() => setHidden(hidden.includes("Dra. Andrea Ramos") ? hidden.filter((h) => h !== "Dra. Andrea Ramos") : [...hidden, "Dra. Andrea Ramos"])} />
              <i className="doctor-dot green" /> Dra. Andrea Ramos
            </label>
            <label>
              <input type="checkbox" checked={!hidden.includes("Dr. Luis Cárdenas")} onChange={() => setHidden(hidden.includes("Dr. Luis Cárdenas") ? hidden.filter((h) => h !== "Dr. Luis Cárdenas") : [...hidden, "Dr. Luis Cárdenas"])} />
              <i className="doctor-dot coral" /> Dr. Luis Cárdenas
            </label>
            <div className="agenda-summary">
              <b>{appointments.length}</b>
              <span>Citas hoy</span>
              <small>2 espacios disponibles</small>
            </div>
          </aside>
          <div className="day-agenda">
            <div className="agenda-day-head">
              <span>Horario</span>
              <div>
                <small>MIÉ 18</small>
                <b>{offset === 0 ? "Hoy" : "Sin citas"}</b>
              </div>
            </div>
            {[
              "08:00",
              "09:00",
              "10:00",
              "11:00",
              "12:00",
              "13:00",
              "14:00",
              "15:00",
              "16:00",
              "17:00",
            ].map((time) => {
              const item = visible.find((a) =>
                a.time.startsWith(time.slice(0, 2)),
              )
              return (
                <div className="time-row" key={time}>
                  <span>{time}</span>
                  <div>
                    {item && (
                      <article
                        onClick={() => cycle(item)}
                        title="Clic para cambiar el estado"
                        className={`calendar-event event-${item.status.toLowerCase().replace(" ", "-")}`}
                      >
                        <div>
                          <b>
                            {item.time} · {item.patient}
                          </b>
                          <small>
                            {item.reason} · {item.doctor}
                          </small>
                        </div>
                        <Status>{item.status}</Status>
                      </article>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </section>
    </div>
  )
}

function Consultations({
  consultations,
  setConsultations,
  patients,
}: {
  consultations: Consultation[]
  setConsultations: (items: Consultation[]) => void
  patients: Patient[]
}) {
  const [formOpen, setFormOpen] = useState(false)
  const [openId, setOpenId] = useState<number | null>(null)
  const [form, setForm] = useState({
    patient: patients[0]?.name || "",
    diagnosis: "",
    procedure: "",
    doctor: "Dra. Andrea Ramos",
  })
  const save = (e: FormEvent) => {
    e.preventDefault()
    if (!form.diagnosis || !form.procedure) return
    setConsultations([
      { id: Date.now(), ...form, date: "Hoy · ahora" },
      ...consultations,
    ])
    setFormOpen(false)
  }
  return (
    <div className="page">
      <section className="section-head">
        <div>
          <h2>Consultas dentales</h2>
          <p>Registra atenciones y mantén la trazabilidad clínica.</p>
        </div>
        <Button onClick={() => setFormOpen(!formOpen)}>
          <Icon name="plus" size={18} /> Nueva consulta
        </Button>
      </section>
      <div className="consult-grid">
        <section className="card consultation-list">
          <div className="card-head">
            <div>
              <h3>Atenciones recientes</h3>
              <p>{consultations.length} registros clínicos</p>
            </div>
            <div className="table-search compact">
              <Icon name="search" size={17} />
              <input placeholder="Buscar" />
            </div>
          </div>
          {consultations.map((item) => (
            <article className="consult-item" key={item.id}>
              <div className="patient-avatar">
                {item.patient
                  .split(" ")
                  .slice(0, 2)
                  .map((n) => n[0])
                  .join("")}
              </div>
              <div className="consult-main">
                <div>
                  <b>{item.patient}</b>
                  <Status>Completada</Status>
                </div>
                <span>{item.diagnosis}</span>
                <small>{item.procedure}</small>
                <p>
                  <Icon name="clock" size={14} />
                  {item.date} · {item.doctor}
                </p>
                {openId === item.id && (
                  <p className="consult-detail">
                    <b>Diagnóstico:</b> {item.diagnosis}
                  </p>
                )}
              </div>
              <button className="row-action" aria-label="Ver detalle" onClick={() => setOpenId(openId === item.id ? null : item.id)}>
                <Icon name="arrow" size={17} />
              </button>
            </article>
          ))}
        </section>
        <aside className="card clinical-note">
          <span className="eyebrow">
            {formOpen ? "NUEVA ATENCIÓN" : "RESUMEN CLÍNICO"}
          </span>
          {formOpen ? (
            <form onSubmit={save}>
              <label>
                Paciente
                <select
                  value={form.patient}
                  onChange={(e) =>
                    setForm({ ...form, patient: e.target.value })
                  }
                >
                  {patients.map((p) => (
                    <option key={p.id}>{p.name}</option>
                  ))}
                </select>
              </label>
              <label>
                Diagnóstico
                <textarea
                  required
                  value={form.diagnosis}
                  onChange={(e) =>
                    setForm({ ...form, diagnosis: e.target.value })
                  }
                  placeholder="Diagnóstico clínico"
                />
              </label>
              <label>
                Procedimiento
                <textarea
                  required
                  value={form.procedure}
                  onChange={(e) =>
                    setForm({ ...form, procedure: e.target.value })
                  }
                  placeholder="Procedimientos realizados"
                />
              </label>
              <Button type="submit">Guardar consulta</Button>
              <Button
                type="button"
                variant="ghost"
                onClick={() => setFormOpen(false)}
              >
                Cancelar
              </Button>
            </form>
          ) : (
            <>
              <h3>Actividad de esta semana</h3>
              <div className="clinical-stat">
                <span>
                  <Icon name="clipboard" />
                </span>
                <div>
                  <b>24</b>
                  <small>Consultas atendidas</small>
                </div>
              </div>
              <div className="clinical-stat">
                <span>
                  <Icon name="tooth" />
                </span>
                <div>
                  <b>18</b>
                  <small>Procedimientos realizados</small>
                </div>
              </div>
              <div className="clinical-stat">
                <span>
                  <Icon name="calendar" />
                </span>
                <div>
                  <b>7</b>
                  <small>Próximos controles</small>
                </div>
              </div>
              <div className="clinical-alert">
                <b>Seguridad clínica</b>
                <p>
                  Cada modificación queda registrada con fecha y profesional
                  responsable.
                </p>
              </div>
            </>
          )}
        </aside>
      </div>
    </div>
  )
}

function IncomeReport() {
  const [period, setPeriod] = useState("2025-06")
  const [doctor, setDoctor] = useState("Todos")
  const [method, setMethod] = useState("Todos")

  const filtered = useMemo(
    () =>
      incomeRecords.filter(
        (record) =>
          record.date.startsWith(period) &&
          (doctor === "Todos" || record.doctor === doctor) &&
          (method === "Todos" || record.method === method),
      ),
    [period, doctor, method],
  )
  const total = filtered.reduce((sum, record) => sum + record.amount, 0)
  const average = filtered.length ? total / filtered.length : 0
  const byMethod = ["Tarjeta", "Transferencia", "Efectivo"].map((name) => ({
    name,
    value: filtered
      .filter((record) => record.method === name)
      .reduce((sum, record) => sum + record.amount, 0),
  }))

  const exportCsv = () => {
    const rows = [
      [
        "Código",
        "Fecha",
        "Paciente",
        "Concepto",
        "Odontólogo",
        "Método",
        "Importe",
      ],
      ...filtered.map((record) => [
        record.id,
        record.date,
        record.patient,
        record.concept,
        record.doctor,
        record.method,
        record.amount.toFixed(2),
      ]),
    ]
    const csv = rows
      .map((row) => row.map((cell) => `"${cell}"`).join(","))
      .join("\n")
    const link = document.createElement("a")
    link.href = URL.createObjectURL(
      new Blob([csv], { type: "text/csv;charset=utf-8" }),
    )
    link.download = `reporte-ingresos-${period}.csv`
    link.click()
    URL.revokeObjectURL(link.href)
  }

  return (
    <div className="page income-report">
      <section className="section-head">
        <div>
          <h2>Reporte de ingresos</h2>
          <p>
            Consulta los ingresos registrados por periodo, profesional y método.
          </p>
        </div>
        <div className="report-actions">
          <Button variant="secondary" onClick={() => window.print()}>
            <Icon name="file" size={17} /> Imprimir
          </Button>
          <Button onClick={exportCsv}>
            <Icon name="chart" size={17} /> Exportar CSV
          </Button>
        </div>
      </section>

      <section className="card report-filters">
        <label>
          Periodo
          <select
            value={period}
            onChange={(event) => setPeriod(event.target.value)}
          >
            <option value="2025-06">Junio 2025</option>
            <option value="2025-05">Mayo 2025</option>
          </select>
        </label>
        <label>
          Odontólogo
          <select
            value={doctor}
            onChange={(event) => setDoctor(event.target.value)}
          >
            <option>Todos</option>
            <option>Dra. Andrea Ramos</option>
            <option>Dr. Luis Cárdenas</option>
          </select>
        </label>
        <label>
          Método
          <select
            value={method}
            onChange={(event) => setMethod(event.target.value)}
          >
            <option>Todos</option>
            <option>Tarjeta</option>
            <option>Transferencia</option>
            <option>Efectivo</option>
          </select>
        </label>
        <Button
          variant="secondary"
          onClick={() => {
            setPeriod("2025-06")
            setDoctor("Todos")
            setMethod("Todos")
          }}
        >
          Limpiar filtros
        </Button>
      </section>

      <section className="income-metrics">
        <article className="card income-total">
          <span>INGRESOS DEL PERIODO</span>
          <strong>
            S/ {total.toLocaleString("es-PE", { minimumFractionDigits: 2 })}
          </strong>
          <small>
            <Icon name="trend" size={14} /> 12.5% frente al periodo anterior
          </small>
        </article>
        <article className="card income-stat">
          <span>OPERACIONES</span>
          <strong>{filtered.length}</strong>
          <small>Ingresos registrados</small>
        </article>
        <article className="card income-stat">
          <span>PROMEDIO POR INGRESO</span>
          <strong>
            S/ {average.toLocaleString("es-PE", { maximumFractionDigits: 0 })}
          </strong>
          <small>Ticket promedio</small>
        </article>
      </section>

      <section className="income-overview">
        <article className="card income-chart-card">
          <div className="card-head">
            <div>
              <h3>Evolución de ingresos</h3>
              <p>Acumulado por día durante el periodo</p>
            </div>
          </div>
          <div className="income-bars">
            {[38, 52, 44, 70, 58, 76, 63, 88, 74, 94].map((height, index) => (
              <div className="income-bar-column" key={index}>
                <div className="income-bar" style={{ height: `${height}%` }} />
                <span>{index + 1 < 10 ? `0${index + 1}` : index + 1} Jun</span>
              </div>
            ))}
          </div>
        </article>
        <article className="card method-card">
          <div className="card-head">
            <div>
              <h3>Por método</h3>
              <p>Distribución de ingresos</p>
            </div>
          </div>
          <div className="method-list">
            {byMethod.map((item) => (
              <div key={item.name}>
                <span>
                  <i
                    className={`method-dot method-${item.name.toLowerCase()}`}
                  />
                  {item.name}
                  <b>S/ {item.value.toLocaleString("es-PE")}</b>
                </span>
                <div>
                  <i
                    style={{
                      width: `${total ? (item.value / total) * 100 : 0}%`,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </article>
      </section>

      <section className="card table-card income-table">
        <div className="card-head">
          <div>
            <h3>Detalle de ingresos</h3>
            <p>{filtered.length} movimientos encontrados</p>
          </div>
        </div>
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>Código</th>
                <th>Fecha</th>
                <th>Paciente y concepto</th>
                <th>Odontólogo</th>
                <th>Método</th>
                <th>Importe</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((record) => (
                <tr key={record.id}>
                  <td>
                    <b>{record.id}</b>
                  </td>
                  <td>
                    {new Date(`${record.date}T12:00:00`).toLocaleDateString(
                      "es-PE",
                      { day: "2-digit", month: "short", year: "numeric" },
                    )}
                  </td>
                  <td>
                    <b>{record.patient}</b>
                    <small>{record.concept}</small>
                  </td>
                  <td>{record.doctor}</td>
                  <td>
                    <span className="income-method">{record.method}</span>
                  </td>
                  <td className="income-amount">
                    S/ {record.amount.toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="empty">
            <Icon name="chart" size={28} />
            <h3>Sin ingresos para estos filtros</h3>
            <p>Selecciona otro periodo o cambia los filtros.</p>
          </div>
        )}
      </section>
    </div>
  )
}

function usePersist<T>(key: string, initial: T): [T, (v: T) => void] {
  const [value, setValue] = useState<T>(() => {
    try {
      const raw = safeStorage.getItem(key);
      return raw ? JSON.parse(raw) : initial;
    } catch (e) {
      return initial;
    }
  });
  useEffect(() => {
    safeStorage.setItem(key, JSON.stringify(value));
  }, [value]);
  return [value, setValue];
}

function useToast(): [any, (m: string) => void] {
  const [msg, setMsg] = useState("");
  const show = (m: string) => {
    setMsg(m);
    window.setTimeout(() => setMsg(""), 2500);
  };
  return [
    msg ? (
      <div className="toast">
        <Icon name="check" size={18} />
        {msg}
      </div>
    ) : null,
    show,
  ];
}

function Records({ patients, consultations, setConsultations }: any) {
  const [q, setQ] = useState("");
  const [selId, setSelId] = useState<number | null>(patients[0]?.id ?? null);
  const [form, setForm] = useState({ diagnosis: "", procedure: "" });
  const [toast, show] = useToast();
  const list = patients.filter((p: Patient) =>
    `${p.name} ${p.code} ${p.document}`.toLowerCase().includes(q.toLowerCase()),
  );
  const p: Patient | undefined =
    patients.find((x: Patient) => x.id === selId) || patients[0];
  const history = p
    ? consultations.filter((c: Consultation) => c.patient === p.name)
    : [];
  const age = p
    ? Math.floor((Date.now() - new Date(p.birth).getTime()) / 31557600000)
    : 0;
  const add = (e: FormEvent) => {
    e.preventDefault();
    if (!p || !form.diagnosis.trim()) return;
    const d = new Date();
    const hh = String(d.getHours()).padStart(2, "0");
    const mm = String(d.getMinutes()).padStart(2, "0");
    setConsultations([
      {
        id: Date.now(),
        patient: p.name,
        date: `Hoy, ${hh}:${mm}`,
        doctor: "Dra. Andrea Ramos",
        diagnosis: form.diagnosis,
        procedure: form.procedure || "Evaluación clínica",
      },
      ...consultations,
    ]);
    setForm({ diagnosis: "", procedure: "" });
    show("Nota clínica agregada.");
  };
  return (
    <div className="page">
      <section className="section-head">
        <div>
          <h2>Historias clínicas</h2>
          <p>Antecedentes, diagnósticos y evolución de cada paciente.</p>
        </div>
      </section>
      <div className="x-split">
        <aside className="card x-list">
          <input
            className="x-input"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Buscar paciente…"
          />
          {list.map((x: Patient) => (
            <button
              key={x.id}
              className={`x-item ${p && x.id === p.id ? "x-active" : ""}`}
              onClick={() => setSelId(x.id)}
            >
              <b>{x.name}</b>
              <small>
                {x.code} · {x.status}
              </small>
            </button>
          ))}
          {list.length === 0 && <p className="x-muted">Sin resultados.</p>}
        </aside>
        {p ? (
          <div className="x-stack">
            <section className="card">
              <span className="eyebrow">FICHA DEL PACIENTE</span>
              <h2 className="x-title">{p.name}</h2>
              <div className="x-facts">
                <span><small>Edad</small><b>{age} años</b></span>
                <span><small>Documento</small><b>{p.document}</b></span>
                <span><small>Teléfono</small><b>{p.phone}</b></span>
                <span><small>Correo</small><b>{p.email}</b></span>
                <span><small>Alergias</small><b className="x-warn">{p.allergy}</b></span>
                <span><small>Última visita</small><b>{p.lastVisit}</b></span>
              </div>
            </section>
            <section className="card">
              <h3>Nueva nota clínica</h3>
              <form className="x-form" onSubmit={add}>
                <label>
                  Diagnóstico
                  <input
                    className="x-input"
                    value={form.diagnosis}
                    onChange={(e) => setForm({ ...form, diagnosis: e.target.value })}
                    placeholder="Ej. Caries en pieza 36"
                  />
                </label>
                <label>
                  Procedimiento
                  <input
                    className="x-input"
                    value={form.procedure}
                    onChange={(e) => setForm({ ...form, procedure: e.target.value })}
                    placeholder="Ej. Obturación con resina"
                  />
                </label>
                <Button type="submit">Agregar a la historia</Button>
              </form>
            </section>
            <section className="card">
              <h3>Línea de tiempo ({history.length})</h3>
              <div className="x-timeline">
                {history.map((c: Consultation) => (
                  <article key={c.id}>
                    <i />
                    <div>
                      <b>{c.diagnosis}</b>
                      <small>{c.procedure}</small>
                      <p>{c.date} · {c.doctor}</p>
                    </div>
                  </article>
                ))}
                {history.length === 0 && (
                  <p className="x-muted">Este paciente aún no tiene atenciones registradas.</p>
                )}
              </div>
            </section>
          </div>
        ) : (
          <section className="card"><p className="x-muted">No hay pacientes registrados.</p></section>
        )}
      </div>
      {toast}
    </div>
  );
}

const TOOTH_COLORS: Record<string, string> = {
  Sano: "#dff5ee",
  Caries: "#ef6f61",
  Obturación: "#6aa8ff",
  Corona: "#f2c14e",
  Endodoncia: "#a98be8",
  Ausente: "#cfd6d4",
};
const UPPER_TEETH = [18, 17, 16, 15, 14, 13, 12, 11, 21, 22, 23, 24, 25, 26, 27, 28];
const LOWER_TEETH = [48, 47, 46, 45, 44, 43, 42, 41, 31, 32, 33, 34, 35, 36, 37, 38];

function Odontogram({ patients }: any) {
  const [charts, setCharts] = usePersist<Record<string, Record<number, string>>>("smileup-odontograms", {});
  const [patient, setPatient] = useState(patients[0]?.name || "");
  const [tool, setTool] = useState("Caries");
  const chart = charts[patient] || {};
  const paint = (n: number) => {
    const next = chart[n] === tool ? "Sano" : tool;
    setCharts({ ...charts, [patient]: { ...chart, [n]: next } });
  };
  const findings = Object.entries(chart).filter(([, s]) => s !== "Sano");
  const row = (teeth: number[]) => (
    <div className="x-teeth">
      {teeth.map((n) => {
        const s = chart[n] || "Sano";
        return (
          <button key={n} className="x-tooth" onClick={() => paint(n)} title={`Pieza ${n}: ${s}`}>
            <span className="x-crown" style={{ background: TOOTH_COLORS[s], opacity: s === "Ausente" ? 0.45 : 1 }} />
            <small>{n}</small>
          </button>
        );
      })}
    </div>
  );
  return (
    <div className="page">
      <section className="section-head">
        <div>
          <h2>Odontograma digital</h2>
          <p>Selecciona un hallazgo y toca la pieza dental (numeración FDI).</p>
        </div>
        <select className="x-input x-select" value={patient} onChange={(e) => setPatient(e.target.value)}>
          {patients.map((p: Patient) => (
            <option key={p.id}>{p.name}</option>
          ))}
        </select>
      </section>
      <section className="card">
        <div className="x-legend">
          {Object.keys(TOOTH_COLORS).filter((k) => k !== "Sano").map((k) => (
            <button key={k} className={tool === k ? "x-active" : ""} onClick={() => setTool(k)}>
              <i style={{ background: TOOTH_COLORS[k] }} /> {k}
            </button>
          ))}
        </div>
        <div className="x-arch">
          <span className="eyebrow">SUPERIOR</span>
          {row(UPPER_TEETH)}
          <div className="x-midline" />
          {row(LOWER_TEETH)}
          <span className="eyebrow">INFERIOR</span>
        </div>
      </section>
      <section className="card">
        <div className="card-head">
          <div>
            <h3>Hallazgos registrados ({findings.length})</h3>
            <p>{patient}</p>
          </div>
          {findings.length > 0 && (
            <Button variant="secondary" onClick={() => setCharts({ ...charts, [patient]: {} })}>
              Limpiar odontograma
            </Button>
          )}
        </div>
        <div className="x-findings">
          {findings.map(([n, s]) => (
            <span key={n}>
              <i style={{ background: TOOTH_COLORS[s] }} /> Pieza {n} · {s}
            </span>
          ))}
          {findings.length === 0 && <p className="x-muted">Sin hallazgos: todas las piezas figuran como sanas.</p>}
        </div>
      </section>
    </div>
  );
}

const PLAN_STATES = ["Pendiente", "En curso", "Completado"];

function Treatments({ patients }: any) {
  const name = (i: number) => patients[i]?.name || patients[0]?.name || "";
  const [items, setItems] = usePersist<any[]>("smileup-treatments", !patients.length ? [] : [
    { id: 1, patient: name(0), procedure: "Endodoncia", tooth: "36", price: 850, status: "En curso" },
    { id: 2, patient: name(1), procedure: "Limpieza dental", tooth: "—", price: 120, status: "Completado" },
    { id: 3, patient: name(2), procedure: "Control de ortodoncia", tooth: "—", price: 200, status: "Pendiente" },
  ]);
  const [form, setForm] = useState({ patient: name(0), procedure: "", tooth: "", price: "" });
  const [toast, show] = useToast();
  const total = items.reduce((s, i) => s + i.price, 0);
  const done = items.filter((i) => i.status === "Completado").reduce((s, i) => s + i.price, 0);
  const pct = total ? Math.round((done / total) * 100) : 0;
  const money = (n: number) => `S/ ${n.toLocaleString("es-PE", { minimumFractionDigits: 2 })}`;
  const add = (e: FormEvent) => {
    e.preventDefault();
    const price = parseFloat(form.price);
    if (!form.procedure.trim() || !form.patient || isNaN(price)) return;
    setItems([...items, { id: Date.now(), patient: form.patient, procedure: form.procedure, tooth: form.tooth || "—", price, status: "Pendiente" }]);
    setForm({ ...form, procedure: "", tooth: "", price: "" });
    show("Tratamiento agregado al plan.");
  };
  const next = (id: number) =>
    setItems(items.map((i) => i.id === id ? { ...i, status: PLAN_STATES[(PLAN_STATES.indexOf(i.status) + 1) % 3] } : i));
  return (
    <div className="page">
      <section className="section-head">
        <div>
          <h2>Planes de tratamiento</h2>
          <p>Procedimientos, presupuesto y avance. Toca el estado para cambiarlo.</p>
        </div>
      </section>
      <section className="x-kpis">
        <article className="card"><small>Presupuesto total</small><strong>{money(total)}</strong></article>
        <article className="card"><small>Ejecutado</small><strong>{money(done)}</strong></article>
        <article className="card">
          <small>Avance general</small><strong>{pct}%</strong>
          <div className="x-bar"><i style={{ width: `${pct}%` }} /></div>
        </article>
      </section>
      <section className="card">
        <h3>Nuevo tratamiento</h3>
        <form className="x-form x-form-row" onSubmit={add}>
          <select className="x-input" value={form.patient} onChange={(e) => setForm({ ...form, patient: e.target.value })}>
            {patients.map((p: Patient) => <option key={p.id}>{p.name}</option>)}
          </select>
          <input className="x-input" placeholder="Procedimiento" value={form.procedure} onChange={(e) => setForm({ ...form, procedure: e.target.value })} />
          <input className="x-input" placeholder="Pieza (ej. 36)" value={form.tooth} onChange={(e) => setForm({ ...form, tooth: e.target.value })} />
          <input className="x-input" placeholder="Precio S/" type="number" min="0" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
          <Button type="submit"><Icon name="plus" size={18} /> Agregar</Button>
        </form>
      </section>
      <section className="card table-card">
        <div className="table-scroll">
          <table>
            <thead>
              <tr><th>Paciente</th><th>Procedimiento</th><th>Pieza</th><th>Precio</th><th>Estado</th><th></th></tr>
            </thead>
            <tbody>
              {items.map((i) => (
                <tr key={i.id}>
                  <td><b>{i.patient}</b></td>
                  <td>{i.procedure}</td>
                  <td>{i.tooth}</td>
                  <td>{money(i.price)}</td>
                  <td>
                    <button className={`x-chip x-chip-${i.status.replace(" ", "-").toLowerCase()}`} onClick={() => next(i.id)}>{i.status}</button>
                  </td>
                  <td><button className="x-link" onClick={() => setItems(items.filter((t) => t.id !== i.id))}>Quitar</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {items.length === 0 && <div className="empty"><h3>Sin tratamientos</h3><p>Agrega el primero con el formulario.</p></div>}
      </section>
      {toast}
    </div>
  );
}

const DAYS = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];
const RESET_KEYS = ["smileup-patients", "smileup-appointments", "smileup-consultations", "smileup-treatments", "smileup-odontograms", "smileup-settings", "smileup-pros", "smileup-schedule"];

function SettingsPage() {
  const [cfg, setCfg] = usePersist("smileup-settings", {
    name: CURRENT_CLINIC, phone: "", email: "", address: "", remind: true,
  });
  const [draft, setDraft] = useState(cfg);
  const [pros, setPros] = usePersist<any[]>("smileup-pros", [
    { id: 1, name: "Dra. Andrea Ramos", role: "Odontóloga general" },
    { id: 2, name: "Dr. Luis Cárdenas", role: "Endodoncista" },
  ]);
  const [np, setNp] = useState({ name: "", role: "" });
  const [sched, setSched] = usePersist<any[]>("smileup-schedule", DAYS.map((d, i) => ({ day: d, on: i < 6, from: i === 5 ? "09:00" : "08:00", to: i === 5 ? "13:00" : "18:00" })));
  const [toast, show] = useToast();
  const setDay = (i: number, patch: any) => setSched(sched.map((s, k) => (k === i ? { ...s, ...patch } : s)));
  return (
    <div className="page">
      <section className="section-head">
        <div>
          <h2>Configuración del centro</h2>
          <p>Datos de la clínica, profesionales, horarios y preferencias.</p>
        </div>
      </section>
      <div className="x-grid2">
        <section className="card">
          <h3>Datos de la clínica</h3>
          <form className="x-form" onSubmit={(e) => { e.preventDefault(); setCfg(draft); show("Datos guardados."); }}>
            <label>Nombre<input className="x-input" value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} /></label>
            <label>Teléfono<input className="x-input" value={draft.phone} onChange={(e) => setDraft({ ...draft, phone: e.target.value })} /></label>
            <label>Correo<input className="x-input" value={draft.email} onChange={(e) => setDraft({ ...draft, email: e.target.value })} /></label>
            <label>Dirección<input className="x-input" value={draft.address} onChange={(e) => setDraft({ ...draft, address: e.target.value })} /></label>
            <Button type="submit">Guardar cambios</Button>
          </form>
        </section>
        <section className="card">
          <h3>Profesionales</h3>
          <div className="x-pros">
            {pros.map((p) => (
              <div key={p.id}>
                <span><b>{p.name}</b><small>{p.role}</small></span>
                <button className="x-link" onClick={() => setPros(pros.filter((x) => x.id !== p.id))}>Quitar</button>
              </div>
            ))}
          </div>
          <form className="x-form x-form-row" onSubmit={(e) => {
            e.preventDefault();
            if (!np.name.trim()) return;
            setPros([...pros, { id: Date.now(), name: np.name, role: np.role || "Odontólogo" }]);
            setNp({ name: "", role: "" });
            show("Profesional agregado.");
          }}>
            <input className="x-input" placeholder="Nombre" value={np.name} onChange={(e) => setNp({ ...np, name: e.target.value })} />
            <input className="x-input" placeholder="Especialidad" value={np.role} onChange={(e) => setNp({ ...np, role: e.target.value })} />
            <Button type="submit">Agregar</Button>
          </form>
        </section>
        <section className="card">
          <h3>Horario de atención</h3>
          <div className="x-sched">
            {sched.map((s, i) => (
              <div key={s.day}>
                <label><input type="checkbox" checked={s.on} onChange={(e) => setDay(i, { on: e.target.checked })} /> {s.day}</label>
                {s.on ? (
                  <span>
                    <input className="x-input" type="time" value={s.from} onChange={(e) => setDay(i, { from: e.target.value })} />
                    <input className="x-input" type="time" value={s.to} onChange={(e) => setDay(i, { to: e.target.value })} />
                  </span>
                ) : <small className="x-muted">Cerrado</small>}
              </div>
            ))}
          </div>
        </section>
        <section className="card">
          <h3>Preferencias</h3>
          <label className="x-toggle">
            <input type="checkbox" checked={cfg.remind} onChange={(e) => { setCfg({ ...cfg, remind: e.target.checked }); setDraft({ ...draft, remind: e.target.checked }); }} />
            Recordatorios de cita al paciente (24 h antes)
          </label>
          <p className="x-muted">Los cambios se guardan en este navegador.</p>
          <Button variant="secondary" onClick={() => { RESET_KEYS.forEach((k) => safeStorage.removeItem(k)); window.location.reload(); }}>
            Restablecer datos de demostración
          </Button>
        </section>
      </div>
      {toast}
    </div>
  );
}

function ComingSoon({ section }: { section: Section }) {
  const details: Record<string, [string, string, string]> = {
    "Historias clínicas": [
      "Expedientes centralizados",
      "Consulta antecedentes, diagnósticos y evolución del paciente en una línea de tiempo clínica.",
      "file",
    ],
    Odontograma: [
      "Odontograma digital",
      "Registra hallazgos por pieza FDI, tratamientos planificados y evolución clínica.",
      "tooth",
    ],
    Tratamientos: [
      "Planes de tratamiento",
      "Organiza procedimientos, presupuestos y avances de cada paciente.",
      "sparkles",
    ],
    Configuración: [
      "Configuración del centro",
      "Administra profesionales, horarios, roles y preferencias.",
      "settings",
    ],
  }
  const detail = details[section] || [
    "Módulo",
    "Contenido en preparación.",
    "settings",
  ]
  return (
    <div className="page">
      <section className="section-head">
        <div>
          <h2>{section}</h2>
          <p>Módulo integrado de gestión Smile Up.</p>
        </div>
      </section>
      <section className="card feature-preview">
        <div className="feature-icon">
          <Icon name={detail[2]} size={36} />
        </div>
        <span className="eyebrow">SIGUIENTE ETAPA</span>
        <h2>{detail[0]}</h2>
        <p>{detail[1]}</p>
        <div className="feature-list">
          <span>
            <Icon name="check" size={17} /> Integrado con la ficha del paciente
          </span>
          <span>
            <Icon name="check" size={17} /> Permisos según rol profesional
          </span>
          <span>
            <Icon name="check" size={17} /> Historial de modificaciones
          </span>
        </div>
        <Button>Explorar módulo</Button>
      </section>
    </div>
  )
}

function Workspace({ clinic, onLogout }: { clinic: any; onLogout: () => void }) {
  const isDemo = clinic.slug === "smile-up-demo"
  const [section, setSection] = useState<Section>("Inicio")
  const [search, setSearch] = useState("")
  const [menuOpen, setMenuOpen] = useState(false)
  const [patients, setPatients] = useState<Patient[]>(
    () =>
      JSON.parse(safeStorage.getItem("smileup-patients") || "null") ||
      (isDemo ? initialPatients : []),
  )
  const [appointments, setAppointments] = useState<Appointment[]>(
    () =>
      JSON.parse(safeStorage.getItem("smileup-appointments") || "null") ||
      (isDemo ? initialAppointments : []),
  )
  const [consultations, setConsultations] = useState<Consultation[]>(
    () =>
      JSON.parse(safeStorage.getItem("smileup-consultations") || "null") ||
      (isDemo ? initialConsultations : []),
  )

  useEffect(
    () => safeStorage.setItem("smileup-patients", JSON.stringify(patients)),
    [patients],
  )
  useEffect(
    () =>
      safeStorage.setItem(
        "smileup-appointments",
        JSON.stringify(appointments),
      ),
    [appointments],
  )
  useEffect(
    () =>
      safeStorage.setItem(
        "smileup-consultations",
        JSON.stringify(consultations),
      ),
    [consultations],
  )
  const content = useMemo(() => {
    if (section === "Inicio")
      return <Dashboard appointments={appointments} goTo={setSection} />
    if (section === "Pacientes")
      return (
        <Patients
          patients={patients}
          setPatients={setPatients}
          search={search}
        />
      )
    if (section === "Agenda")
      return (
        <Agenda
          appointments={appointments}
          setAppointments={setAppointments}
          patients={patients}
        />
      )
    if (section === "Consultas")
      return (
        <Consultations
          consultations={consultations}
          setConsultations={setConsultations}
          patients={patients}
        />
      )
    if (section === "Reporte de ingresos") return <IncomeReport />
    if (section === "Historias clínicas")
      return <Records patients={patients} consultations={consultations} setConsultations={setConsultations} />
    if (section === "Odontograma") return <Odontogram patients={patients} />
    if (section === "Tratamientos") return <Treatments patients={patients} />
    if (section === "Configuración") return <SettingsPage />
    return <ComingSoon section={section} />
  }, [section, search, patients, appointments, consultations])

  return (
    <div className="app-shell">
      <Sidebar
        section={section}
        setSection={setSection}
        open={menuOpen}
        close={() => setMenuOpen(false)}
        logout={() => {
          onLogout()
        }}
      />
      <div className="main-shell">
        <Header
          section={section}
          search={search}
          setSearch={(v: string) => {
            setSearch(v)
            if (v && section !== "Pacientes") setSection("Pacientes")
          }}
          toggleMenu={() => setMenuOpen(true)}
          goTo={setSection}
          logout={() => {
            safeStorage.removeItem("smileup-session")
            setLoggedIn(false)
          }}
        />
        <main>{content}</main>
      </div>
    </div>
  )
}

function App() {
  const [clinic, setClinic] = useState<any>(() => {
    try {
      const v = JSON.parse(safeStorage.getItem("smileup-session") || "null")
      return v && v.slug ? v : null
    } catch (e) {
      return null
    }
  })
  CURRENT_CLINIC = clinic ? clinic.name : ""
  if (!clinic) return <Login onLogin={setClinic} />
  return (
    <Workspace
      key={clinic.slug}
      clinic={clinic}
      onLogout={() => {
        safeStorage.removeItem("smileup-session")
        safeStorage.setTenant("")
        setClinic(null)
      }}
    />
  )
}

export default App
