# CRM Odontológico

Plataforma para varios centros odontológicos: cada centro crea su espacio y ve solo sus datos.
Versión actual: los datos se guardan en el navegador (demostración). Para producción, conecta Supabase
(`supabase_schema.sql` ya trae las tablas y las reglas de seguridad por centro y por rol).

## Probar en tu computadora
Requiere Node.js 20 o superior.

    npm install
    npm run dev

## Subir a Vercel
1. Crea un repositorio en GitHub y sube todo el contenido de esta carpeta (sin `node_modules`).
2. En vercel.com: **Add New → Project** → importa ese repositorio.
3. Vercel detecta Vite solo. Deja los valores por defecto y presiona **Deploy**.
4. Al terminar te da un link público.

Alternativa sin GitHub: instala la CLI (`npm i -g vercel`) y ejecuta `vercel` dentro de esta carpeta.

## Acceso de demostración
- Para ver datos de ejemplo hay un centro de demostración; para producción, elimina esa cuenta de demostración.
- Nuevo centro: pestaña "Crear mi centro".

## Seguridad (léelo antes de usar datos reales)
- **No uses datos reales de pacientes con esta versión.** El login es de demostración (no verifica la contraseña)
  y los datos se guardan sin cifrar en el navegador.
- El código de una página web es visible para cualquiera. Por eso **nunca** pongas claves secretas en este proyecto.
  Solo se puede incluir la clave pública `anon` de Supabase; la protegen las reglas del archivo `supabase_schema.sql`.
- **Nunca** subas a GitHub ni pegues en el código la clave `service_role` de Supabase ni archivos `.env` con secretos.
- `vercel.json` ya activa cabeceras de seguridad (CSP, anti-clickjacking, HTTPS estricto, etc.).
- Con Supabase: activa verificación de correo y autenticación en dos pasos, usa contraseñas fuertes y revisa
  las reglas de acceso antes de abrir el sistema a pacientes reales.
